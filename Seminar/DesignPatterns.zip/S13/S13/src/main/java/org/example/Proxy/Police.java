package org.example.Proxy;

public interface Police {

    public void registerPlate(String plateNumber);
}
