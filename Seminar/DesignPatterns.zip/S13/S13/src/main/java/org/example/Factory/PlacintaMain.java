package org.example.Factory;

public class PlacintaMain {

    public static void main(String[] args) {
        Placintarie placintarie = new Placintarie();
        placintarie.coace("Placinta cu Cartofi");
    }
}
