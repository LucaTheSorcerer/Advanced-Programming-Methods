package org.example.Adapter;

public interface Pay {

    //always pays in RON
    public void pay(int amount);
}
