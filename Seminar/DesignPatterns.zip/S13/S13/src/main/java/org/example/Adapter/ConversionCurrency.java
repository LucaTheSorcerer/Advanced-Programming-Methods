package org.example.Adapter;

public interface ConversionCurrency {

    public void pay(int amount);
}
