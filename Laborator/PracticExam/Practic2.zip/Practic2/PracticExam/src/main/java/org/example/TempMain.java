package org.example;

import java.util.List;

public class TempMain {

    public static void main(String[] args) {

//        City city1 = new City("Cluj", "Romania", List.of(new Temperatures()));
        City city2 = new City("Bucuresti", "Romania", List.of());
        City city3 = new City("Sibiu","Romania", List.of());
        City city4 = new City("Brasov", "Romania", List.of());


    }

}
