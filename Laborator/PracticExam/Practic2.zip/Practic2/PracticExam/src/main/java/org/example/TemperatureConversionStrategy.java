package org.example;

public interface TemperatureConversionStrategy {

    double convert(double temperature);
}
