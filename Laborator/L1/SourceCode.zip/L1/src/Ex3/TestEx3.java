package Ex3;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import java.util.Arrays;

public class TestEx3 {

    private static final String TEST_ONE = "Sum of numbers in arrays";
    private static final String TEST_TWO = "Difference of numbers in arrays";
    private static final String TEST_THREE = "Multiplication of number in array with integer";
    private static final String TEST_FOUR = "Division of number in array with integer";


    private static final String SUCCESSFUL = "was successful";
    private static final String FAILED = "has failed";

    private Ex3 ex3;

    @BeforeEach
    public void setUp() {
        ex3 = new Ex3();
    }

    @Test
    public void testAddition() {
        int[] number1 = {1, 3, 0, 0, 0, 0, 0, 0, 0};
        int[] number2 = {8, 7, 0, 0, 0, 0, 0, 0, 0};

        int[] expectedResult = {1, 0, 0, 0, 0, 0, 0, 0, 0, 0};

        int[] result = Ex3.sum(number1, number2);

        printAssertionResult(expectedResult, result, TEST_ONE);
    }

    @Test
    public void testSubtraction() {
        int[] number1 = {8, 3, 0, 0, 0, 0, 0};
        int[] number2 = {5, 4, 0, 0, 0, 0, 0};

        int[] expectedResult = {2, 9, 0, 0, 0, 0, 0};

        int[] result = Ex3.subtract(number1, number2);

        printAssertionResult(expectedResult, result, TEST_TWO);
    }

    @Test
    public void testMultiplication() {
        int[] number = {2, 3, 6, 0, 0, 0, 0, 0, 0};
        int integer = 2;

        int[] expectedResult = {4, 7, 2, 0, 0, 0, 0, 0, 0};

        int[] result = Ex3.multiply(number, integer);

        printAssertionResult(expectedResult, result, TEST_THREE);
    }

    @Test
    public void testDivision() {
        int[] number = {2, 3, 6, 0, 0, 0, 0, 0, 0};
        int divisor = 2;

        int[] expectedResult = {1, 1, 8, 0, 0, 0, 0, 0, 0};

        int[] result = Ex3.divide(number, divisor);

        printAssertionResult(expectedResult, result, TEST_FOUR);
    }


    private void printAssertionResult(int[] expectedResult, int[] result, String testTwo) {
        System.out.println("Result: " + Arrays.toString(result));
        System.out.println("Expected: " + Arrays.toString(expectedResult));

        Assertions.assertArrayEquals(expectedResult, result);

        if(Arrays.equals(expectedResult, result)) {
            testLogger(testTwo, SUCCESSFUL);
        } else {
            testLogger(testTwo, FAILED);
        }
    }


    private static void testLogger(String testName, String result) {
        System.out.println("Test: " + testName + " " + result);
    }

}
